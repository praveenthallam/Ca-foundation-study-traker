# CA Foundation Study Tracker V7 FINAL

A responsive CA Foundation study tracker designed for Android phones and laptop/desktop browsers.

## Included
- PRAVEEN profile photo in the app interface and launcher icon
- 4 default CA Foundation subjects and 46 chapters
- Chapter completion and live progress percentages
- Daily study-hour target and exam countdown
- Question Papers: separate Questions and Answers storage
- Upload, open, rename and delete files
- Full Edit Mode in Settings
  - rename/delete subjects
  - add new subjects
  - edit/delete chapters
  - add new chapters
  - rename/delete question-paper categories
  - add new question-paper categories
  - change profile name
- Responsive mobile and laptop/desktop layout
- Local persistence with localStorage + IndexedDB
- PWA support for laptop/desktop browsers
- Cloud Sync option using the user's own GitHub repository

## Phone ↔ laptop synchronization
The app is local-first. For automatic cross-device matching, use **Settings → Cloud Sync** on both devices with the same private GitHub repository.

The app syncs:
- chapter progress
- profile/settings
- custom subjects and chapters
- question-paper categories
- uploaded question files
- uploaded answer files
- deletions

Use a **private repository** for study files. GitHub access is controlled by the user's own fine-grained token and is stored only in the browser/app storage.

For large files, keep individual uploads under about 8 MB for the built-in GitHub sync path. Local storage can hold larger files subject to browser/device limits.

## Android
Open this project in Android Studio or connect the repository to Codemagic. The committed `codemagic.yaml` builds a debug APK. Internet permission is enabled for Cloud Sync.

## Laptop
Open `web/index.html` in a modern browser, or serve the `web` folder from a local web server. The interface automatically expands for larger screens and can be installed as a PWA when the browser supports it.
