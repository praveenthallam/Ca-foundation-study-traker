# Build the APK in the cloud

This project is prepared for cloud APK builders. The easiest options are Codemagic or GitHub Actions.

## Option A — Codemagic (recommended for a simple APK)

Codemagic can build native Android projects and expose `.apk` files as build artifacts.

1. Put this project in a GitHub repository.
2. Open Codemagic and connect your GitHub account/repository.
3. Select this repository and choose the Android/native Android project.
4. Make sure `codemagic.yaml` is detected at the repository root.
5. Start the `android-apk` workflow.
6. When the build finishes, download the APK from the build artifacts.

This workflow intentionally builds `assembleDebug`, which creates an installable APK without requiring you to create/upload a release keystore.

For a public Play Store release, use a signed release build and keep the signing keystore private.

## Option B — GitHub Actions

The project already includes:

`.github/workflows/build-apk.yml`

1. Create a GitHub repository.
2. Upload/push this whole project.
3. Open GitHub → Actions → "Build CA Foundation APK".
4. Choose "Run workflow".
5. When it finishes, download the artifact named:
   `CA-Foundation-Study-Tracker-APK`

## Important

The generated debug APK is suitable for installing/testing directly on your Android phone. It is not the final Play Store-signed release.

For Google Play, Android release signing is required. Codemagic supports uploading a private Android keystore and using it for signed release builds. Never put a keystore or passwords into a public GitHub repository.
