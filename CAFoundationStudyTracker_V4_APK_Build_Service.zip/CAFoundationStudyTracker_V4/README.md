# CA Foundation Study Tracker — Version 4

Professional dashboard for all 46 chapters:
- Accounting: 11
- Business Laws: 7
- Quantitative Aptitude: 18
- Business Economics: 10

Version 4 features:
- Professional dashboard UI
- Overall and subject-wise percentages
- Completed/remaining chapter counts
- Chapter checklists
- Daily study-hour target and quick hour logging
- Exam countdown with user-selected exam date
- Revision progress indicator
- Offline local storage
- Android Studio project

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync and install required SDK components.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK: app/build/outputs/apk/debug/app-debug.apk


## Cloud APK build
See `BUILD_APK.md`. The project includes `codemagic.yaml` and a GitHub Actions workflow that build an installable APK in the cloud.
